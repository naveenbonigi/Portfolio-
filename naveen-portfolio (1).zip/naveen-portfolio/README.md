# Bonigi Naveen — Portfolio

A responsive personal portfolio built with plain HTML, CSS and JavaScript.

## Sections
Home, About, Skills, Projects, Education and certification, Strengths, Contact.

## Features
- Photo and quick-facts card in the hero
- Light and dark themes (follows the system setting)
- Mobile-friendly layout, keyboard focus styles, reduced-motion support
- Active section highlighting in the nav

## Files
- `index.html` — page content
- `style.css` — styles
- `script.js` — nav highlighting
- `images/naveen.jpg` — profile photo

## Run
Open `index.html` in a browser, or use VS Code Live Server. To host it free, upload the folder to GitHub Pages or Netlify.
