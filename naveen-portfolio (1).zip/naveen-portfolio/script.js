// Highlight the nav link for the section currently in view.
const links = [...document.querySelectorAll('nav a')];
const byId = id => links.find(a => a.getAttribute('href') === '#' + id);
const io = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    links.forEach(a => a.removeAttribute('aria-current'));
    const link = byId(e.target.id);
    if (link) link.setAttribute('aria-current', 'true');
  });
}, { rootMargin: '-40% 0px -55% 0px' });
document.querySelectorAll('main section[id]').forEach(sec => io.observe(sec));
